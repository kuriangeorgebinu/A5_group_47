package edu.gatech.cs6310.commandutils.basic;
public interface CommandUtils { // To specify a common commandType to plug into the Map of the CommandUtilsFactoryConfiguration
}
