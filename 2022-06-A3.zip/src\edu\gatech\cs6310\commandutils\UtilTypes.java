package edu.gatech.cs6310.commandutils;

public enum UtilTypes {
    ORDER,
    PROPERTY,
    ASSET,
    USER
}
